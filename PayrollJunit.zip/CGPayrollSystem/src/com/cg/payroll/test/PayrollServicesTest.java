package com.cg.payroll.test;
import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;


public class PayrollServicesTest {
	private static PayrollServices payrollServices;
	//private static PayrollUtility utility;
	@BeforeClass
	public static void setUpTestEnv(){
		payrollServices=new PayrollServicesImpl();	
	}

	@AfterClass
	public static void tearDownTestEnv(){
		payrollServices=null;
	}
	@Before
	public  void setUpMockData() {
		Associate associate1=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,500000,"Teju", "Kuppa","Training","analyst","enn21","er@g", new Salary(20000,100,200), new BankDetails(2020,"abbank","24ef"));
		Associate associate2=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,500003,"Avani", "Reddy","Training","analyst","enn21","er@g", new Salary(20005,102,209), new BankDetails(2021,"acbank","24e5"));
		Associate associate3=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,500002,"Sam", "Thanku","Training","analyst","enn21","er@g", new Salary(20006,103,208), new BankDetails(2022,"aebank","24e6"));
		PayrollDAOServicesImpl.associates.put(associate1.getAssociateId(),associate1);
		PayrollDAOServicesImpl.associates.put(associate2.getAssociateId(),associate2);
		PayrollDAOServicesImpl.associates.put(associate3.getAssociateId(),associate3);
		//PayrollDAOServicesImpl.associates.put(associate1.getAssociateId(), associate1);

	}
	@After
	public  void tearDownMockData(){
		PayrollDAOServicesImpl.associates.clear();
		PayrollUtility.ASSOCIATE_ID_COUNTER=111;

	}
	@Test
	public void validAssociateDetails() throws AssociateDetailsNotFoundException{
		Associate expectedass=payrollServices.getAssociateDetails(112);
		Assert.assertEquals(expectedass,new Associate(112,500003,"Avani", "Reddy","Training","analyst","enn21","er@g", new Salary(20005,102,209), new BankDetails(2021,"acbank","24e5")));
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void inValidAssociateDetails() throws AssociateDetailsNotFoundException{
		Associate exceptedass=payrollServices.getAssociateDetails(114);
		Assert.assertEquals(exceptedass,new Associate(113,500002,"Sam", "Thanku","Training","analyst","enn21","er@g", new Salary(20006,103,208), new BankDetails(2022,"aebank","24e6")));
	}
	@Test
	public void testSalary() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		//Associate expectedSal=payrollServices.calculateNetSalary(112);
		Assert.assertEquals(36518.75833333333, payrollServices.calculateNetSalary(112),0);
	}
	@Test
	public void testGetValidAssociateDetails() throws AssociateDetailsNotFoundException {
	Associate associate1 = new Associate(111,500000,"Teju", "Kuppa","Training","analyst","enn21","er@g", new Salary(20000,100,200), new BankDetails(2020,"abbank","24ef"));
	Assert.assertEquals(associate1,payrollServices.getAssociateDetails(111) );
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetInValidAssociateDetails() throws AssociateDetailsNotFoundException{
	payrollServices.getAssociateDetails(115);
	}
	
	
}



