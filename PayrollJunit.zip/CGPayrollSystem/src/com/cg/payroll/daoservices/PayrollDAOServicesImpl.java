package com.cg.payroll.daoservices;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.utility.PayrollUtility;
public class PayrollDAOServicesImpl implements PayrollDAOServices {

	public  static HashMap<Integer, Associate>associates=new HashMap<>();
	@Override
	public int insertAssociate(Associate associate) {
		associate.setAssociateId(PayrollUtility.ASSOCIATE_ID_COUNTER++);
		return associate.getAssociateId();
		
	}

	@Override
	public boolean updateAssociate(Associate associate) {
		associates.put(associate.getAssociateId(),associate);
		return true;
	}
	
	public boolean deleteAssociate(int associateId){
		associates.remove(associateId);
		return false;
	}
	@Override
	public Associate getAssociate(int associateId) {
		return associates.get(associateId);
	}
	
	@Override
	public List<Associate> getAssociates() {
		return new ArrayList<Associate>(associates.values());
	}
}
